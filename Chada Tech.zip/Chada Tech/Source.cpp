//Name: Evan Arthur
// Chada Tech Clock
//11.13.2022

#include <iostream>
#include <windows.h>
#include <iomanip>
using namespace std;

// Time class 
class Time {
public:
    int h1;
    int h2;
    int m1;
    int m2;
    int s1;
    int s2;

    Time() {
        this->h1 = 12;
        this->h2 = 00;
        this->m1 = 00;
        this->m2 = 00;
        this->s1 = 00;
        this->s2 = 00;
    }
    //used to prevent time from exceeding max amount
    void managetime(int t = 1) {
        if (t == 1)//12 hour clock
        {
            if (s1 / 60 > 0)
            {
                s1 %= 60;
                m1++;
            }
            if (m1 / 60 > 0)
            {
                m1 %= 60;
                h1++;
            }
            if (h1 / 12 > 0)
            {
                h1 %= 12;
                if (h1 == 0) {
                    h1 = 12;
                }
            }
        }
        if (t == 2)//24 hour clock
        {
            if (s2 / 60 > 0)
            {
                s2 %= 60;
                m2++;
            }
            if (m2 / 60 > 0)
            {
                m2 %= 60;
                h2++;
            }
            if (h2 / 24 > 0)
            {
                h1 %= 24;
                if (h2 == 24) {
                    h2 = 0;
                }
            }
        }

    }
    // function to add 1 sec
    void addSecond() {
        s1++;
        s2++;
        managetime(1);
        managetime(2);
    }

    // function to wait 1 sec
    void waitSecond() {
            Sleep(1000);
            s1++;
            s2++;
            managetime(1);
            managetime(2);
    }

    // function to add 1 min
    void addMinute() {
        m1++;
        m2++;
        managetime(1);
        managetime(2);
    }

    // function to add 1 hour
    void addHour() {
        h1++;
        h2++;
        managetime(1);
        managetime(2);
    }

    // function to display both times
    void displayTime() {
        if (h2 < 12) {
            cout << setfill('*') << setw(38) << "" << endl;
            cout << setfill(' ');
            cout << "*" << setw(16) << left << " 12-Hour Clock:" << "* ";
            cout << " *" << setw(16) << right << "24-Hour Clock: " << "*" << endl;
            cout << "*";
            printf(" %02d:%02d:%02d", h1, m1, s1);
            cout << " A M";
            cout << "   *  * ";
            printf("%02d:%02d:%02d", h2, m2, s2);
            cout << "       *" << endl;
            cout << setfill('*') << setw(38) << "" << endl;
            cout << setfill(' ');
        }
        else {
            cout << setfill('*') << setw(38) << "" << endl;
            cout << setfill(' ');
            cout << "*" << setw(16) << left << " 12-Hour Clock:" << "* ";
            cout << " *" << setw(16) << right << "24-Hour Clock: " << "*" << endl;
            cout << "*";
            printf(" %02d:%02d:%02d", h1, m1, s1);
            cout << " P M";
            cout << "   *  * ";
            printf("%02d:%02d:%02d", h2, m2, s2);
            cout << "       *" << endl;
            cout << setfill('*') << setw(38) << "" << endl;
            cout << setfill(' ');
        }
    }
};
    int main() {
        Time t;
        int userInput;
        int f = 1;

        // Get input, update clock, reapeat process
        while (f > 0) {
            t.displayTime();
            cout << endl;
            cout << setfill('*') << setw(22) << "" << endl;
            cout << setfill(' ');
            cout << "* 1 - Add One Hour   *" << endl;
            cout << "* 2 - Add One Minute *" << endl;
            cout << "* 3 - Add One Second *" << endl; 
            cout << "* 4 - Exit Program   *" << endl;
            cout << setfill('*') << setw(22) << "" << endl;
            cout << setfill(' ');
            cin >> userInput; 
            switch (userInput) {
            case 1: t.addHour(); break;
            case 2: t.addMinute(); break;
            case 3: t.addSecond(); break;
            case 4: f = -1; break;
            }
            system("CLS");
        }
        return 0;
    }
