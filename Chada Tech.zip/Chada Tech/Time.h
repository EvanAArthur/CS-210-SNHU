#pragma once
#include <iostream>
using namespace std;
/*Build a class to check both 12 and 24 hour clocks
for proper display
functions will add time and diplay clocks*/

class Time
{
public:
	int h1;
	int h2;
	int m1;
	int m2;
	int s1;
	int s2;
}

	Time() //default constructor for 12 and 24 hr
	{
		this->h1 = 12;
		this->h2 = 00;
		this->m1 = 00;
		this->m2 = 00;
		this->s1 = 00;
		this->s2 = 00;
	}
    void managetime(int t = 1)
    {
        if (t == 1)
        {
            if (s1 / 60 > 0)
            {
                s1 %= 60;
                m1++;
            }
            if (m1 / 60 > 0)
            {
                m1 %= 60;
                h1++;
            }
            if (h1 / 12 > 0)
            {
                h1 %= 12;
                if (h1 == 0)
                    h1 = 12;
            }
        }
        if (t == 2)
        {
            if (s2 / 60 > 0)
            {
                s2 %= 60;
                m2++;
            }
            if (m2 / 60 > 0)
            {
                m2 %= 60;
                h2++;
            }
            if (h2 / 24 > 0)
            {
                h1 %= 24;
            }
        }

    }
    // function to add 1 sec
    void addSecond()
    {
        s1++;
        s2++;
        managetime(1);
        managetime(2);
    }

    // function to wait 1 sec
    void waitSecond()
    {
        s1++;
        s2++;
        managetime(1);
        managetime(2);
    }

    // function to add 1 min
    void addMinute()
    {
        m1++;
        m2++;
        managetime(1);
        managetime(2);
    }

    // function to add 1 hour
    void addHour()
    {
        h1++;
        h2++;
        managetime(1);
        managetime(2);
    }

    // function to display both times
    void display()
    {
        printf("\nTime 1: %02d:%02d:%02d\n", h1, m1, s1);
        printf("Time 2: %02d:%02d:%02d\n\n", h2, m2, s2);
    }
};